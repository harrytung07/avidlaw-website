"use client";

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import NavBar from './NavBar';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { useTranslation } from '@/context/TranslationContext';
import ReactMarkdown from 'react-markdown'; 
import { Article, MultiLangContent } from '@/lib/articles';

interface ArticlesProps {
  initialArticles: Article[];
}

const uiContent = {
  heroTitle: {
    en: "Legal Insights & Articles",
    'zh-Hans': "法律见解与深度文章",
    'zh-Hant': "法律見解與深度文章",
  },
  heroDescription: {
    en: "Expert-written articles on various legal topics to help you navigate complex legal matters. Stay informed with our in-depth analyses, practical guides, and insightful perspectives.",
    'zh-Hans': "由资深律师团队撰写的各类法律文章，助您从容应对复杂的法律事务。通过深入的成文法分析与实用指南，随时掌握最新法律资讯。",
    'zh-Hant': "由資深律師團隊撰寫的各類法律文章，助您從容應對複雜的法律事務。透過深入的成文法分析與實用指南，隨時掌握最新法律資訊。",
  },
  readArticleBtn: {
    en: "Read Article",
    'zh-Hans': "阅读完整文章",
    'zh-Hant': "閱讀完整文章",
  },
  allCategories: {
    en: "All Categories",
    'zh-Hans': "所有分类",
    'zh-Hant': "所有分類",
  },
  ctaTitle: {
    en: "Have Legal Questions?",
    'zh-Hans': "面临法律疑问或纠纷？",
    'zh-Hant': "面臨法律疑問或糾紛？",
  },
  ctaDescription: {
    en: "Our team is ready to provide expert advice tailored to your specific situation. Reach out today for a confidential consultation.",
    'zh-Hans': "安胜 · 弘人律师团队随时准备针对您的具体个案提供专业建议。立即联系我们进行法律咨询。",
    'zh-Hant': "安勝 · 弘人律師團隊隨時準備針對您的具體個案提供專業建議。立即聯繫我們進行法律諮詢。",
  },
  contactBtn: {
    en: "Book a Consultation",
    'zh-Hans': "预约法律咨询",
    'zh-Hant': "預約法律諮詢",
  }
};

export default function Articles({ initialArticles }: ArticlesProps) { 
  const { locale, t } = useTranslation();
  const [showModal, setShowModal] = useState(false);
  const [showNavbar, setShowNavbar] = useState(true);
  
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(
    initialArticles.length > 0 ? initialArticles[0] : null
  );

  const localePath = (path: string) => {
    if (path.startsWith(`/${locale}`)) return path;
    if (path === '/' || path === '') return `/${locale}`;
    if (path === '/#contact' || path === '#contact') return `/${locale}#contact`;
    if (path.startsWith('/')) return `/${locale}${path}`;
    return `/${locale}/${path}`;
  };

  const getLocalizedContent = (content: string | MultiLangContent): string => {
    if (typeof content === 'string') return content;
    return content[locale as keyof MultiLangContent] || content.en || '';
  };

  const [selectedCategory, setSelectedCategory] = useState(getLocalizedContent(uiContent.allCategories));

  useEffect(() => {
    setSelectedCategory(getLocalizedContent(uiContent.allCategories));
  }, [locale]);

  useEffect(() => {
    if (showModal) {
      setShowNavbar(false);
      document.body.style.overflow = 'hidden';
    } else {
      setShowNavbar(true);
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [showModal]);

  const categories = [
    getLocalizedContent(uiContent.allCategories),
    ...Array.from(new Set(initialArticles.map(article => getLocalizedContent(article.category))))
  ];

  const filteredArticles = selectedCategory === getLocalizedContent(uiContent.allCategories)
    ? initialArticles
    : initialArticles.filter(article => getLocalizedContent(article.category) === selectedCategory);

  const closeArticle = () => {
    setShowModal(false);
  };

  return (
    <div className="bg-zinc-100/70 text-zinc-900 min-h-screen">
      {showNavbar && <NavBar />}
      
      {/* Hero section */}
      <section className="relative pt-32 pb-24 md:pt-40 md:pb-32 bg-[#0B1B48] text-white overflow-hidden text-center">
        <div className="absolute inset-0 z-0">
          <Image 
            src="/sideBG.png" 
            alt="Articles Background" 
            fill 
            className="object-cover opacity-20 brightness-110" 
            priority
          />
          <div className="absolute inset-0 bg-[#0B1B48]/85 mix-blend-multiply"></div>
        </div>
        
        <div className="relative z-10 container mx-auto px-6 max-w-4xl">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FFC107]/15 border border-[#FFC107]/30 text-[#FFC107] text-xs font-semibold uppercase tracking-wider mb-6">
            Avid Law Legal Knowledge Base
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-white mb-6">
            {getLocalizedContent(uiContent.heroTitle)}
          </h1>
          <div className="h-1 w-24 bg-[#FFC107] mx-auto mb-8 rounded-full"></div>
          <p className="text-base sm:text-lg md:text-xl text-zinc-200/90 leading-relaxed font-light">
            {getLocalizedContent(uiContent.heroDescription)}
          </p>
        </div>
      </section>
      
      {/* Category filters & Article grid */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-6 max-w-7xl">
          <div className="flex flex-col md:flex-row justify-between items-center mb-10">
            <div className="w-full overflow-x-auto pb-4 md:pb-0 no-scrollbar">
              <div className="flex space-x-2 md:space-x-3 min-w-max">
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 ${
                      selectedCategory === category
                        ? 'bg-[#0B1B48] text-[#FFC107] shadow-md'
                        : 'bg-white text-zinc-700 border border-zinc-200 hover:bg-zinc-100 hover:text-zinc-900 shadow-sm'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
          </div>
          
          <div>
            <style jsx global>{`
              .no-scrollbar::-webkit-scrollbar { display: none; }
              .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
            `}</style>
            
            {/* Article grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredArticles.map((article) => (
                <div 
                  key={article.id} 
                  className="bg-white rounded-2xl overflow-hidden shadow-md border border-zinc-200 hover:border-[#FFC107] hover:shadow-xl transition-all duration-300 flex flex-col group"
                >
                  {/* Image container */}
                  <div className="relative w-full h-[220px] bg-zinc-100 overflow-hidden">
                    <Image
                      src={article.image}
                      alt={getLocalizedContent(article.title)}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-[#0B1B48]/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 p-4">
                      <Link
                        href={localePath(`/articles/${article.id}`)}
                        className="bg-[#FFC107] text-[#0B1B48] font-bold py-2.5 px-5 rounded-lg shadow-lg transform transition-all duration-300 hover:bg-[#ffcb38] hover:scale-105 text-xs uppercase tracking-wider"
                      >
                        {getLocalizedContent(uiContent.readArticleBtn)}
                      </Link>
                    </div>
                  </div>

                  <div className="p-6 flex-grow flex flex-col">
                    <div className="flex items-center justify-between mb-3.5">
                      <span className="bg-[#0B1B48]/10 text-[#0B1B48] text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-md">
                        {getLocalizedContent(article.category)}
                      </span>
                      <span className="text-zinc-400 text-xs font-medium">{article.date}</span>
                    </div>

                    {/* Crawlable Title Link */}
                    <h3 className="font-serif font-bold text-lg text-zinc-900 group-hover:text-[#0B1B48] transition-colors mb-3 line-clamp-2">
                      <Link
                        href={localePath(`/articles/${article.id}`)}
                        className="hover:text-[#0B1B48] transition-colors"
                      >
                        {getLocalizedContent(article.title)}
                      </Link>
                    </h3>

                    <p className="text-zinc-600 mb-6 text-sm line-clamp-3 flex-grow leading-relaxed">
                      {getLocalizedContent(article.preview)}
                    </p>

                    <div className="flex items-center justify-between mt-auto pt-4 border-t border-zinc-100">
                      <div className="flex items-center">
                        <Image src="/chatbot1.png" alt="Author" width={32} height={32} className="rounded-full mr-2.5 bg-zinc-100" />
                        <div>
                          <p className="font-semibold text-xs text-zinc-900">{article.author}</p>
                          <p className="text-[11px] text-zinc-500">{article.role}</p>
                        </div>
                      </div>

                      <Link
                        href={localePath(`/articles/${article.id}`)}
                        className="text-xs font-bold text-[#0B1B48] group-hover:text-[#FFC107] inline-flex items-center gap-1 transition-colors"
                      >
                        <span>{getLocalizedContent(uiContent.readArticleBtn)}</span>
                        <span>→</span>
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      
      {/* Call to action section */}
      <section className="relative py-20 md:py-28 bg-[#0B1B48] text-white overflow-hidden text-center">
        <div className="absolute inset-0 z-0">
          <Image src="/sideBG.png" alt="Background" fill className="object-cover opacity-15 brightness-110" />
          <div className="absolute inset-0 bg-[#0B1B48]/85 mix-blend-multiply"></div>
        </div>
        
        <div className="relative z-10 container mx-auto px-6 max-w-4xl">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-white mb-6">
            {getLocalizedContent(uiContent.ctaTitle)}
          </h2>
          <div className="h-1 w-24 bg-[#FFC107] mx-auto mb-8 rounded-full"></div>
          <p className="text-base sm:text-lg md:text-xl text-zinc-300 leading-relaxed mb-10 max-w-2xl mx-auto font-light">
            {getLocalizedContent(uiContent.ctaDescription)}
          </p>
          
          <div className="flex justify-center">
            <Link
              href={localePath("/forms?type=consultation")} 
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#FFC107] px-8 py-4 font-bold text-[#0B1B48] transition-all duration-300 hover:bg-[#ffcb38] hover:shadow-xl focus:outline-none shadow-lg text-base"
            >
              <span>{getLocalizedContent(uiContent.contactBtn)}</span>
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-zinc-950 text-zinc-400 py-10 border-t border-zinc-800 text-center">
        <p className="text-sm text-zinc-500">
          {t("footer.copyright").replace("{currentYear}", new Date().getFullYear().toString())}
        </p>
      </footer>
      
      {/* Slide-over Modal retained for inline preview if triggered */}
      <AnimatePresence>
        {showModal && selectedArticle && (
          <motion.div
            className="fixed inset-0 z-50 flex justify-end"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="fixed inset-0 bg-black/70 backdrop-blur-sm" onClick={closeArticle}></div>

            <motion.div
              className="relative w-full md:w-[72%] max-w-4xl h-full bg-zinc-950 border-l border-zinc-800 text-white overflow-y-auto shadow-2xl"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ duration: 0.4, ease: [0.25, 1, 0.5, 1] }}
            >
              <button
                onClick={closeArticle}
                className="absolute top-4 right-4 md:top-6 md:left-6 z-50 p-2.5 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
                aria-label="Close article"
              >
                <X size={24} /> 
              </button>

              <div className="p-6 pt-20 md:p-12 md:pt-24 lg:p-16 text-white max-w-3xl mx-auto">
                <div className="mb-6 md:mb-8 flex items-center gap-3"> 
                  <span className="bg-[#FFC107]/15 border border-[#FFC107]/30 text-[#FFC107] text-xs uppercase font-bold tracking-wider px-3 py-1 rounded-md">
                    {getLocalizedContent(selectedArticle.category)}
                  </span>
                  <span className="text-zinc-400 text-sm">{selectedArticle.date}</span>
                </div>

                <h1 className="text-2xl sm:text-3xl md:text-4xl font-serif font-bold mb-6 text-white leading-tight">
                  {getLocalizedContent(selectedArticle.title)}
                </h1>

                <div className="flex items-center mb-8 pb-6 border-b border-zinc-800">
                  <Image src="/chatbot1.png" alt="Author" width={48} height={48} className="rounded-full mr-3.5 bg-zinc-900 border border-zinc-800" />
                  <div>
                    <p className="font-semibold text-white">{selectedArticle.author}</p>
                    <p className="text-xs text-zinc-400">{selectedArticle.role}</p>
                  </div>
                </div>

                <div className="prose prose-base md:prose-lg prose-invert max-w-none text-zinc-300 leading-relaxed">
                  <ReactMarkdown
                    components={{
                      a: ({ node, ...props }) => (
                        <a {...props} target="_blank" rel="noopener noreferrer" className="text-[#FFC107] hover:underline" />
                      ),
                    }}
                  >
                    {getLocalizedContent(selectedArticle.content)}
                  </ReactMarkdown>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}