"use client";

import Image from 'next/image';
import Link from 'next/link';
import NavBar from '@/components/NavBar';
import { useTranslation } from '@/context/TranslationContext';
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

export interface NewsPost {
  slug: string;
  frontmatter: {
    [key: string]: any;
    title?: string;
    date?: string;
    author?: string;
    featuredImage?: string;
    preview?: string;
  };
  content: string;
}

interface NewsClientProps {
  newsPosts: NewsPost[];
}

const uiContent = {
  en: {
    heroTitle: "Firm News & Updates",
    heroDescription: "Stay informed about the latest legal developments, firm announcements, and community involvement from Avid Law.",
    readMore: "Read More →",
    noNews: "No news articles found.",
  },
  'zh-Hans': {
    heroTitle: "律所新闻与动态",
    heroDescription: "及时了解安胜 · 弘人律师行的最新法律动态、重大公告及社区参与活动。",
    readMore: "阅读全文 →",
    noNews: "暂无新闻文章。",
  },
  'zh-Hant': {
    heroTitle: "律所新聞與動態",
    heroDescription: "及時了解安勝 · 弘人律師行的最新法律動態、重大公告及社區參與活動。",
    readMore: "閱讀全文 →",
    noNews: "暫無新聞文章。",
  },
};

export default function NewsClient({ newsPosts }: NewsClientProps) {
  const { locale, t } = useTranslation();
  const currentLocale = (locale === 'zh-Hans' || locale === 'zh-Hant' ? locale : 'en') as 'en' | 'zh-Hans' | 'zh-Hant';
  const content = uiContent[currentLocale];

  const [showModal, setShowModal] = useState(false);
  const [showNavbar, setShowNavbar] = useState(true);
  const [selectedNewsPost, setSelectedNewsPost] = useState<NewsPost | null>(null);

  useEffect(() => {
    setShowNavbar(!showModal);
  }, [showModal]);

  const closeNewsModal = () => {
    setShowModal(false);
    setSelectedNewsPost(null);
    document.body.style.overflow = 'auto';
  };

  return (
    <div className="min-h-screen bg-zinc-100/70 text-zinc-900">
      {showNavbar && <NavBar />}

      {/* Hero Section */}
      <section className="relative pt-32 pb-24 md:pt-40 md:pb-32 bg-[#0B1B48] text-white overflow-hidden text-center">
        <div className="absolute inset-0 z-0">
          <Image 
            src="/sideBG.png" 
            alt="Background" 
            fill 
            className="object-cover opacity-20 brightness-110" 
            priority 
          />
          <div className="absolute inset-0 bg-[#0B1B48]/85 mix-blend-multiply"></div>
        </div>
        <div className="relative z-10 px-6 max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FFC107]/15 border border-[#FFC107]/30 text-[#FFC107] text-xs font-semibold uppercase tracking-wider mb-6">
            Avid Law Corporation • Press & Updates
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-white mb-6">
            {content.heroTitle}
          </h1>
          <div className="h-1 w-24 bg-[#FFC107] mx-auto mb-8 rounded-full"></div>
          <p className="text-base sm:text-lg md:text-xl text-zinc-200/90 leading-relaxed font-light">
            {content.heroDescription}
          </p>
        </div>
      </section>

      {/* News Feed Section */}
      <section className="relative py-16 md:py-24">
        <div className="container relative z-10 mx-auto px-6 max-w-6xl">
          {newsPosts.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center shadow-sm border border-zinc-200">
              <p className="text-zinc-600 text-lg">{content.noNews}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {newsPosts.map((post) => (
                <article 
                  key={post.slug} 
                  className="bg-white rounded-2xl shadow-md border border-zinc-200 hover:border-[#FFC107] hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col group"
                >
                  {post.frontmatter.featuredImage && (
                    <Link
                      href={`/${locale}/news/${post.slug}`}
                      className="block relative h-48 w-full bg-zinc-100 overflow-hidden"
                    >
                      <Image
                        src={post.frontmatter.featuredImage}
                        alt={post.frontmatter.title || 'Article image'}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </Link>
                  )}
                  <div className="p-6 flex flex-col flex-grow">
                    <div className="flex flex-wrap items-center text-xs text-zinc-400 gap-x-3 gap-y-1 mb-3">
                      {post.frontmatter.date && (
                        <span className="whitespace-nowrap font-medium">
                          📅 {new Date(post.frontmatter.date).toLocaleDateString('en-CA', { month: 'short', day: 'numeric', year: 'numeric' })}
                        </span>
                      )}
                      {post.frontmatter.author && (
                        <span className="whitespace-nowrap font-medium">👤 {post.frontmatter.author}</span>
                      )}
                    </div>

                    <h2 className="text-lg font-serif font-bold mb-3 text-zinc-900 group-hover:text-[#0B1B48] transition-colors line-clamp-2">
                      <Link
                        href={`/${locale}/news/${post.slug}`}
                        className="hover:text-[#0B1B48] transition-colors"
                      >
                        {post.frontmatter.title || 'Untitled News Post'}
                      </Link>
                    </h2>

                    {post.frontmatter.preview && (
                      <p className="text-sm text-zinc-600 mb-5 flex-grow line-clamp-3 leading-relaxed">
                        {post.frontmatter.preview}
                      </p>
                    )}

                    <div className="mt-auto pt-4 border-t border-zinc-100 flex items-center justify-between">
                      <Link
                        href={`/${locale}/news/${post.slug}`}
                        className="text-xs font-bold text-[#0B1B48] group-hover:text-[#FFC107] inline-flex items-center gap-1 transition-colors"
                      >
                        <span>{content.readMore}</span>
                      </Link>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-zinc-950 text-zinc-400 py-10 border-t border-zinc-800 text-center">
        <p className="text-sm text-zinc-500">
          {t("footer.copyright").replace("{currentYear}", new Date().getFullYear().toString())}
        </p>
      </footer>

      {/* News Modal/Canvas retained for inline preview if triggered */}
      <AnimatePresence>
        {showModal && selectedNewsPost && (
          <motion.div
            className="fixed inset-0 z-50 flex justify-end"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div
              className="fixed inset-0 bg-black/70 backdrop-blur-sm"
              onClick={closeNewsModal}
            ></div>

            <motion.div
              className="relative w-full md:w-[72%] max-w-4xl h-full bg-zinc-950 border-l border-zinc-800 text-white overflow-y-auto shadow-2xl"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ duration: 0.4, ease: [0.25, 1, 0.5, 1] }}
            >
              <button
                onClick={closeNewsModal}
                className="absolute top-6 left-6 z-50 p-2.5 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
                aria-label="Close news article"
              >
                <X size={24} />
              </button>

              <div className="p-8 md:p-16 pt-24 text-white max-w-3xl mx-auto">
                {selectedNewsPost.frontmatter.featuredImage && (
                  <div className="relative w-full h-64 md:h-96 mb-8 rounded-2xl overflow-hidden border border-zinc-800">
                    <Image
                      src={selectedNewsPost.frontmatter.featuredImage}
                      alt={selectedNewsPost.frontmatter.title || "News image"}
                      fill
                      className="object-cover"
                    />
                  </div>
                )}
                <div className="mb-6">
                  {selectedNewsPost.frontmatter.date && (
                    <span className="text-zinc-400 text-sm">
                      {new Date(selectedNewsPost.frontmatter.date).toLocaleDateString('en-CA', { month: 'long', day: 'numeric', year: 'numeric' })}
                    </span>
                  )}
                </div>

                <h1 className="text-2xl sm:text-3xl md:text-4xl font-serif font-bold mb-6 leading-tight">
                  {selectedNewsPost.frontmatter.title || "Untitled News Post"}
                </h1>

                {selectedNewsPost.frontmatter.author && (
                  <div className="flex items-center mb-8 pb-6 border-b border-zinc-800">
                    <Image
                      src="/chatbot1.png"
                      alt={selectedNewsPost.frontmatter.author || "Author"}
                      width={48}
                      height={48}
                      className="rounded-full mr-3.5 bg-zinc-900 border border-zinc-800"
                    />
                    <div>
                      <p className="font-semibold text-white">{selectedNewsPost.frontmatter.author}</p>
                    </div>
                  </div>
                )}

                <div className="prose prose-lg prose-invert max-w-none text-zinc-300 leading-relaxed">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {selectedNewsPost.content}
                  </ReactMarkdown>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}